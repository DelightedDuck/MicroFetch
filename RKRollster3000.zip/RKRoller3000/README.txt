⚠USE AT YOUR OWN RISK⚠
only works on windows

Now you are probably asking what is this?
well its just a program that constantly trys to rickroll you 

How to run it
Run the Normal.bat to run with a CMD prompt that you can close to stop it
Run the Invisible.vbs to run invisibly you need restart your pc to stop it