uDrawTablet v8.0.0
Brandon Wilson

>What is it?
This is some C# .NET 2.0 code to allow using the Wii, PS3, and Xbox 360 uDraw tablets on a Windows PC.
When you run it, it places an icon in the notification (tray) area to let you know it's running and to configure options.
Right-click it and choose "Options..." (or just press Y/Triangle on the tablet by default) to bring up the options (which are saved to an INI file in the same directory as the application).
Right-click it and choose "Exit" to quit.

>How do I use it?
Just run it.

>What are the controls?
Use the nib/stylus on the drawing area to move the mouse cursor on the current monitor, press on the pen to left-click (or press A/Cross by default), and press X/Square to right-click (by default). Y/Triangle will bring up the options dialog (by default).

>This sucks, what if I just want to write my own code to control this thing?
You can use the uDrawLib and Xbox360USB DLLs to get access to the tablet data, or you can just do the whole thing yourself by reading the documentation included and online at brandonw.net/udraw.

>Where is the most recent source code?
http://brandonw.net/udraw/ , http://brandonw.net/svn/x86stuff/uDrawTablet/trunk/, and/or GitHub.

>How can I contact you?
brandonw.net, brandonlw@gmail.com, twitter.com/brandonlwilson, etc.
