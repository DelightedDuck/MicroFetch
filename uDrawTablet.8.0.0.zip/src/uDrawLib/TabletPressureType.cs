﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uDrawLib
{
  public enum TabletPressureType
  {
    NotPressed = 0,
    PenPressed = 1,
    FingerPressed = 2,
    Multitouch = 3
  };
}
