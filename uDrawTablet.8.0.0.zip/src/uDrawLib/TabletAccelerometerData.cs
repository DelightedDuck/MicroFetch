﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uDrawLib
{
  public class TabletAccelerometerData
  {
    public ushort XAxis;
    public ushort YAxis;
    public ushort ZAxis;
  };
}
